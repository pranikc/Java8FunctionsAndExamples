package UI;

import java.io.*;
import java.util.List;
import java.util.Scanner;
import Converters.*;
import Utils.ConverterSwitch;
import Utils.InputFileParser;

/**
 * Created by pranikchainani on 7/10/16.
 */
public class CharacterProcessor {
    public static String getString()
    {
        System.out.println("Please input a string to processed in my character processor: ");

        return new Scanner(System.in).nextLine();
    }

    public static String modText(Character character, int choice)
    {
        String moddedText = "";
        Converter lowerCase = new LowerCaseConverter();
        Converter upperCase = new UpperCaseConverter();
        Converter duplicator = new Duplicator();
        Converter zBlocker = new Blockers('z');
        Converter kBlocker = new Blockers('k');
        Converter ZBlocker = new Blockers('Z');

        switch(choice)
        {
            case 0:
                System.out.println("Exiting...");
                System.exit(0);
                break;
            case 1:
                moddedText = lowerCase.converter(character);
                break;
            case 2:
                moddedText = upperCase.converter(character);
                break;
            case 3:
                moddedText = duplicator.converter(character);
                break;
            case 4:
                moddedText = zBlocker.converter(character);
                break;
            case 5:
                moddedText = kBlocker.converter(character);
                break;
            case 6:
                moddedText = ZBlocker.converter(character);
                break;
            default:
                moddedText = "Please enter a value";
        }

        return moddedText;
    }

    public static void main(String[] args) throws IOException {
        String inputText = "asd;lfkjzxcv";
        InputFileParser input = new InputFileParser();
        List<String> classNames = input.inputParser("input.txt");
        for (String converterID : classNames)
        {
            StringWriter buffer = new StringWriter();
            ConverterSwitch converterSwitch = new ConverterSwitch();
            Converter object = converterSwitch.chooseConverter(Integer.parseInt(converterID));

            inputText.chars()
                     .mapToObj(i -> (char) i)
                     .map(object::converter)
                     .forEach(buffer::write);
            inputText = buffer.toString();
        }
        System.out.println(inputText);
    }
}
