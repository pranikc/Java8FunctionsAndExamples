package Utils;

import Converters.*;

/**
 * Created by pranikchainani on 7/30/16.
 */
public class ConverterSwitch {
    public Converter chooseConverter(int converterID)
    {
        switch (converterID)
        {
            case 1:
                return new LowerCaseConverter();
            case 2:
                return new UpperCaseConverter();
            case 3:
                return new Duplicator();
            case 4:
                return new Blockers('k');
            case 5:
                return new Blockers('z');
            case 6:
                return new Blockers('Z');
        }
        return null;
    }
}
