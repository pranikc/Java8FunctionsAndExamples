package Utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pranikchainani on 7/30/16.
 */
public class InputFileParser {
    public List<String> inputParser(String path) throws IOException {
        List<String> classNames = new ArrayList<>();
        Files.lines(Paths.get(path))
                .forEach(classNames::add);
        return classNames;
    }
}
