package Converters;

/**
 * Created by pranikchainani on 7/3/16.
 */
public class Blockers implements Converter {
    Character blockerValue;

    public Blockers(Character blocker){
        blockerValue = blocker;
    }

    public String converter(Character inputValue)
    {
        return inputValue == blockerValue ? "" : inputValue.toString();
    }
}
