package Converters;

/**
 * Created by pranikchainani on 6/25/16.
 */
public class Duplicator implements Converter{
    public String converter(Character character)
    {
        return character.toString() +  character.toString();
    }
}