package Converters;

/**
 * Created by pranikchainani on 6/18/16.
 */
public class LowerCaseConverter implements Converter{
    public String converter(Character character) {
        return String.valueOf(Character.toLowerCase(character));
    }
}
