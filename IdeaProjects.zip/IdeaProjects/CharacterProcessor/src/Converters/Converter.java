package Converters;

/**
 * Created by pranikchainani on 6/18/16.
 */
public interface Converter {
    String converter(Character character);
}