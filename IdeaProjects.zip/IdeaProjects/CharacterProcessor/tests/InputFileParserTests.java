import Utils.InputFileParser;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by pranikchainani on 7/31/16.
 */
public class InputFileParserTests {
    InputFileParser inputFileParser;
    @Before
    public void initialize()
    {
        inputFileParser = new InputFileParser();
    }
    @Test
    public void ReturnsTheCorrectArrayList() throws IOException {
        assertEquals(new ArrayList(Arrays.asList("1", "2", "3", "4", "5", "6")), inputFileParser.inputParser("tests/FileParserTest.txt"));
    }
}