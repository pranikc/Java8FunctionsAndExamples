import Converters.Converter;
import Converters.Duplicator;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by pranikchainani on 6/25/16.
 */

@RunWith(Parameterized.class)
public class DuplicatorTests extends ConverterTests{
    public DuplicatorTests(Character input, String expected){
        super(input, expected);
    }

    @Override
    public Converter createConvertor() {
        return new Duplicator();
    }

    @Parameterized.Parameters
    public static Collection inputValues(){
        return Arrays.asList(new Object[][]{
                {'a', "aa"},
                {'!', "!!"},
                {'1', "11"},
                {' ', "  "}
        });
    }
}