import Converters.Converter;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by pranikchainani on 6/18/16.
 */

public abstract class ConverterTests {
    Converter converter;

    Character inputValue;
    String expectedValue;

    public ConverterTests(Character input, String expectation){
        inputValue = input;
        expectedValue = expectation;
    }

    public abstract Converter createConvertor();

    @Before
    public void initialize(){
        converter = createConvertor();
    }

    @Test
    public void checkIfInputAndExpectedValuesAreEqual(){
        assertEquals(expectedValue,converter.converter(inputValue));
    }
}