import Converters.Converter;
import Converters.UpperCaseConverter;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by pranikchainani on 6/18/16.
 */

@RunWith(Parameterized.class)
public class UpperCaseConverterTests extends ConverterTests {
    public UpperCaseConverterTests(Character input, String expected){
        super(input, expected);
    }

    @Override
    public Converter createConvertor() {
        return new UpperCaseConverter();
    }

    @Parameterized.Parameters
    public static Collection inputValues(){
        return Arrays.asList(new Object[][]{
                {'x', "X"},
                {'!', "!"},
                {'1', "1"},
                {' ', " "}
        });
    }
}