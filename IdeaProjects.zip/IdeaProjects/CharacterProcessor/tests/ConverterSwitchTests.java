import Utils.ConverterSwitch;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

/**
 * Created by pranikchainani on 7/30/16.
 */
@RunWith(Parameterized.class)
public class ConverterSwitchTests {
    ConverterSwitch correctClass;
    @Before
    public void initalize()
    {
        correctClass = new ConverterSwitch();
    }

    int id;
    String className;

    public ConverterSwitchTests(int idNumber, String associatedClass)
    {
        id = idNumber;
        className = associatedClass;
    }

    @Parameterized.Parameters
    public static Collection input(){
        return Arrays.asList( new Object[][]{
                {1, "Converters.LowerCaseConverter"},
                {2, "Converters.UpperCaseConverter"},
                {3, "Converters.Duplicator"},
                {4, "Converters.Blockers"},
                {5, "Converters.Blockers"},
                {6, "Converters.Blockers"}
        });
    }

    @Test
    public void SwitchTests() {
        assertEquals(correctClass.chooseConverter(id).getClass().getName(), className);
    }
}