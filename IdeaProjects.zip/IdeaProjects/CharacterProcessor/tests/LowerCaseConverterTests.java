import Converters.Converter;
import Converters.LowerCaseConverter;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by pranikchainani on 6/18/16.
 */

@RunWith(Parameterized.class)
public class LowerCaseConverterTests extends ConverterTests {
    public LowerCaseConverterTests(Character input, String expected){
        super(input, expected);
    }

    @Override
    public Converter createConvertor() {
        return new LowerCaseConverter();
    }

    @Parameterized.Parameters
    public static Collection inputValues(){
        return Arrays.asList(new Object[][]{
                {'X', "x"},
                {'!', "!"},
                {'1', "1"},
                {' ', " "}
        });
    }
}
