import Converters.Blockers;
import Converters.Converter;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by pranikchainani on 7/3/16.
 */
@RunWith(Parameterized.class)
public class BlockerTests extends ConverterTests {

    private Character characterToBlock;

    public BlockerTests (Character charToBlock, Character input, String expectedOutput){
        super(input, expectedOutput);
        characterToBlock = charToBlock;
    }

    @Override
    public Converter createConvertor() {
        return new Blockers(characterToBlock);
    }

    @Parameterized.Parameters
    public static Collection input(){
        return Arrays.asList( new Object[][]{
                {'z', 'z', ""},
                {'Z', 'Z', ""},
                {'k', 'k', ""},
                {'z', 'a', "a"},
                {'Z', 'a', "a"},
                {'k', 'a', "a"}
        });
    }
}
