import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.stream.Collectors.*;

/**
 * Created by pranikchainani on 6/17/16.
 */
public class Main {

    public static Stream<Integer> factors(int number) {
//        List<Integer> factorsResult = new ArrayList<>();
//        for (int j = 1; j <= numbersPlace; j++) {             // RangeClosed
//            if ((numbersPlace % j) == 0) {                    // filter
//                factorsResult.add(j);                         // collect
//            }
//        }
//        return factorsResult;

        return IntStream.rangeClosed(1,number)
                         .filter(e -> number % e == 0)
                         .boxed();
    }

    public static Set<Integer> listFactors(List<Integer> numbers) {
//        Set<Integer> dispFactors = new HashSet<>();
//        for (int i = 0; i < numbers.size(); i++) {
//            dispFactors.addAll(factors(numbers.get(i)));
//        }
//        return dispFactors;

//        Another Way to solve the problem
//          return numbers.stream()
//                        .map( e -> factors(e))
//                        .reduce(
//                                new HashSet<>(),
//                                (factorsSet, factorOfNumber) ->
//                                            {factorsSet.addAll(factorOfNumber); return factorsSet;},
//                                (set1, set2) ->
//                                            {set1.addAll(set2); return set1;} );

        return numbers.stream()
                        .flatMap(Main::factors)
                        .collect(toSet());
    }

    public static void main(String[] args) {
        List<Integer> setOfNumbers = new ArrayList<>(Arrays.asList(1,4,8,6));
        System.out.println(listFactors(setOfNumbers));
    }
}
