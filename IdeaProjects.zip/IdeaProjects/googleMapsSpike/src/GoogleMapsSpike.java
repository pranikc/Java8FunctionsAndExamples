import com.sun.tools.doclets.formats.html.SourceToHTMLConverter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Created by pranikchainani on 4/16/16.
 */

public class GoogleMapsSpike {
    public static void main(String[] args) throws IOException {
        Properties locationProps = new Properties();
        String urlString = "http://maps.googleapis.com/maps/api/geocode/json?address=77070";

        InputStream inputStream = new URL(urlString).openStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Charset.forName("UTF-8")));

        String jsonText = readAll(bufferedReader);

        JSONObject jsonObject = new JSONObject(jsonText);
        System.out.println(jsonObject);

        JSONArray addressComponents = jsonObject.getJSONArray("results").getJSONObject(0).getJSONArray("address_components");
        JSONObject element = addressComponents.getJSONObject(0);
        String postalCode = element.getString("short_name");
        System.out.println(postalCode);

        element = addressComponents.getJSONObject(1);
        String city = element.getString("short_name");
        System.out.println(city);

        element = addressComponents.getJSONObject(2);
        String county = element.getString("short_name");
        System.out.println(county);

        element = addressComponents.getJSONObject(3);
        String state = element.getString("short_name");
        System.out.println(state);

        element = addressComponents.getJSONObject(4);
        String country = element.getString("short_name");
        System.out.println(country);
    }

    public static String readAll(Reader reader) throws IOException
    {
        StringBuilder stringBuilder = new StringBuilder();
        int currentPosition;

        while((currentPosition = reader.read()) != -1)
        {
            stringBuilder.append((char)currentPosition);
        }

        return stringBuilder.toString();
    }
}
