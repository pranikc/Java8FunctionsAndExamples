import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Created by pranikchainani on 4/16/16.
 */
public class GoogleSpikeKarthikk {

    public Properties getCityAndStateProps(String zipCode) {
        Properties locationProps = new Properties();
        String URLTemplate = "http://maps.googleapis.com/maps/api/geocode/json?address=ZIPCODE";

        try {
            InputStream inputStream = new URL(URLTemplate.replace("ZIPCODE", zipCode)).openStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String locationDetailsString = reader.lines()
                                                 .collect(Collectors.joining("\n"));

            JSONObject locationDetailsJSON = new JSONObject(locationDetailsString);



            JSONArray addressComponentsArray = locationDetailsJSON.getJSONArray("results")
                                                                  .getJSONObject(0)
                                                                  .getJSONArray("address_components");

            for (int i = 0; i < addressComponentsArray.length(); i++) {
                JSONObject addressJSON = addressComponentsArray.getJSONObject(i);

                String infoType = addressJSON.getJSONArray("types").toString();

                if (infoType.contains("postal_code")) {
                    locationProps.put("zipCode", addressJSON.getString("short_name"));
                }
                if (infoType.contains("locality")) {
                    locationProps.put("city", addressJSON.getString("short_name"));
                }
                if (infoType.contains("administrative_area_level_1")) {
                    locationProps.put("state", addressJSON.getString("short_name"));
                }
            }
            inputStream.close();
        } catch (Exception e) {
            System.out.println("Error trying to get Location : "+ e.getMessage());
            System.out.println("Please try again ---- Quiting the Program");
            System.exit(1);
        }



        return locationProps;
    }

}
