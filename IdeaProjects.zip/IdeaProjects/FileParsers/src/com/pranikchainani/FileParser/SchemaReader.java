package com.pranikchainani.FileParser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

/**
 * Created by pranikchainani on 2/27/16.
 */
public class SchemaReader {

    public static void main(String[] args) {
        try
        {
            String directory = "/Users/pranikchainani/Desktop/text.txt";
            ArrayList<String> fileLines = new ArrayList<String>();
            ArrayList<Properties> tableDetails = new ArrayList<Properties>();
            fileLines = Reader(directory);
            System.out.println(fileLines.toString());
            tableDetails = Split(fileLines);
            Display(tableDetails);

        }
        catch (FileNotFoundException error)
        {
            error.printStackTrace();
        }
        catch (IOException IOError)
        {
            IOError.printStackTrace();
        }
    }

    public static ArrayList<String> Reader(String directory) throws IOException {
        FileReader file = new FileReader(directory);
        BufferedReader reader = new BufferedReader(file);
        String str = null;
        ArrayList<String> fileInput = new ArrayList<String>();
        while ( (str  = reader.readLine() )!= null){
            fileInput.add(str);
        }

        file.close();

        return fileInput;
    }

    public static ArrayList<Properties> Split(ArrayList<String> array)
    {
        ArrayList<Properties> tableDetails = new ArrayList<Properties>();

        ArrayList<String> tableName = new ArrayList<String>();
        ArrayList<String> noTableNames = new ArrayList<String>();

        for (String line:array) {
            Properties hashTable = new Properties();
            String[] strArray = line.split("\\(");
            tableName.add(strArray[0]);
            hashTable.put("tableName", strArray[0]);
            String[] tableNameSplit = line.split(strArray[0] + "\\(");
            String tableNamestr = tableNameSplit[1];
            tableNamestr = tableNamestr.substring(0,tableNamestr.length() -1);
            String[] columnNameArray = tableNamestr.split(",");
            ArrayList<String> keyColumns = new ArrayList<String>();
            ArrayList<String> nonKeyColumns = new ArrayList<String>();
            for (String column : columnNameArray){
                if(column.contains("(k)")){
                    String[] keyColumn = column.split("\\(}");
                    keyColumns.add(keyColumn[0].substring(0,keyColumn[0].length() - 3));
                }
                else{
                    nonKeyColumns.add(column);
                }
            }
            hashTable.put("keyColumns",keyColumns);
            hashTable.put("nonKeyColumns",nonKeyColumns);

            tableDetails.add(hashTable);
        }

        return tableDetails;
    }

    public static void Display(ArrayList<Properties> tableValues)
    {
        System.out.println(tableValues.toString());
    }
}