import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by pranikchainani on 7/8/16.
 */
public class ScoresList {

    public static Map<String, Integer> scores = new HashMap<>();

    public static void main(String[] args) {


        scores.put("pranick", 11);
        scores.put("Karthikk", 5);

        Arrays.asList("pranick", "Karthikk", "ash")
                .stream()
                .forEach(ScoresList::incrementScores);

        System.out.println(scores);

    }

    public static void incrementScores(String name) {
//         int currentScore = scores.get(name);
//         scores.put(name, currentScore+1);

        //compute(keyValue, (key, Value) -> process them)
        // merge(key, defaultValue, (currentValue, defaultValue) -> process them);

       // scores.merge(name, 1, (currentValue, newValue) -> currentValue + newValue);

        scores.computeIfAbsent(name, (whatever)-> 1);
        scores.computeIfPresent(name, ScoresList::scoreIncrementer);
       //scores.compute(name, ScoresList::scoreIncrementer);
    }

    public static Integer scoreIncrementer(String ignore, Integer currentScore){
        return currentScore == null ? 1 : currentScore+1;
    }
}
