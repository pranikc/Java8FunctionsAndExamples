import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by pranikchainani on 7/8/16.
 */

//Add Bonjour
public class Greeter {
    public static Map<String, String> greetings = new HashMap<>();

    public static void main(String[] args) {
        greetings.put("Hello", "Karthikk!");
        greetings.put("Howdy", "Karthikk!");
        greetings.put("Wie geht's", "Karthikk!");

        Arrays.asList("Hello", "Howdy", "Bonjour", "Hallo")
                .stream()
                .forEach(Greeter::addBounjour);

        System.out.println(greetings);
    }

//    private static void changeName(Map<String, String> greetings, String howdy) {
//        greetings.compute(howdy, (greeting, name) -> name = "Pranik");
//    }

    private static void addBounjour(String greeting)
    {
        greetings.merge(greeting, "Pranik", (theGreeting, theName) -> theName = "Pranik");
    }
}
