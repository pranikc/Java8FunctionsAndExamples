import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Created by pranikchainani on 6/24/16.
 */
public class PythagoreanTriples {
    /*
    int a = m*m - n*n;
    int b = 2* m* n;
    int c = m*m + n*n;
    Find the first ten triples from 1,1 -> m,n
    where m>n and m>1
     */
    private static List<String> pythagoreanTripleAlgorithm(int m, int n)
    {
        // only send values of m,n -> m>n and m>1
        List<String> triples = new ArrayList<>();
        triples.add("a=>"+ Integer.toString((m*m - n*n)));
        triples.add("b=>"+ Integer.toString(2*m*n));
        triples.add("c=>"+ Integer.toString(m*m + n*n));
        return triples;
    }

    private static void imperativeMethod(int maxValue){
        int counter = 0;
        for (int m = 2; ; m++) {
            for (int n = 1; n < m; n++) {
                if (counter < maxValue){
                    System.out.println(pythagoreanTripleAlgorithm(m, n));
                    counter++;
                }
                else
                    break;
            }
            if(counter >= maxValue)
                break;
        }
    }

    private static Stream<List<String>> triplesForM(int mValue){
        return Stream.iterate(1, n -> n + 1)
                     .map(n -> pythagoreanTripleAlgorithm(mValue, n))
                     .limit(mValue - 1);
    }

    private static void functionalMethod(int maxValue){
        Stream.iterate(2, m -> m + 1)
              .flatMap(PythagoreanTriples::triplesForM)
              .limit(maxValue)
              .forEach(System.out::println);
    }

    public static void main(String[] args) {
        int maxValue = 10;
        imperativeMethod(maxValue);
        System.out.println("___________________________");
        functionalMethod(maxValue);
    }}