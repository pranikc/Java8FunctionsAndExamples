package com.pranikchainani; /**
 * Created by pranikchainani on 5/8/16.
 */

import org.json.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

public class GoogleLocationService implements LocationService {

    public Properties getLocationDetails(String zipCode) {
        Properties properties = new Properties();
        try {
            JSONObject obj = new JSONObject(getText("http://maps.googleapis.com/maps/api/geocode/json?address=" + zipCode));

            JSONArray addressComponents = obj.getJSONArray("results").getJSONObject(0).getJSONArray("address_components");

            JSONObject element = addressComponents.getJSONObject(0);
            properties.setProperty("postalCode", element.getString("short_name"));

            element = addressComponents.getJSONObject(1);
            properties.setProperty("city", element.getString("short_name"));

            element = addressComponents.getJSONObject(3);
            properties.setProperty("state", element.getString("short_name"));
        }
        catch (JSONException | IOException ex) {
            throw new RuntimeException("There was a problem with URL");
        }
        return properties;
    }

    public String getText(String url) throws IOException {
        URL website = new URL(url);
        URLConnection connection = website.openConnection();
        BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        connection.getInputStream()));

        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null)
            response.append(inputLine);

        in.close();

        return response.toString();
    }
}
