package com.pranikchainani;

import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Properties;

/**
 * Created by pranikchainani on 5/15/16.
 */
public interface WeatherService {
    Properties getWeatherDetails(String zip);
}