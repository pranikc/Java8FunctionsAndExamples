package com.pranikchainani;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

/**
 * Created by pranikchainani on 5/15/16.
 */
public class NationalWeatherService implements WeatherService {
    public Properties getWeatherDetails(String zip) {
        Properties properties = new Properties();

        try {
            InputStream is = new URL("http://graphical.weather.gov/xml/sample_products/browser_interface/ndfdBrowserClientByDay.php?zipCodeList=" + zip + "&format=24+hourly&numDays=1").openStream();

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(is);

            doc.getDocumentElement().normalize();

            Element maxTempElem = (Element) doc.getElementsByTagName("temperature").item(0);
            Element minTempElem = (Element) doc.getElementsByTagName("temperature").item(1);
            Element weatherConditionElem = (Element) doc.getElementsByTagName("weather-conditions").item(0);

            properties.put("maxTemp", maxTempElem.getElementsByTagName("value").item(0).getTextContent());
            properties.put("minTemp", minTempElem.getElementsByTagName("value").item(0).getTextContent());
            properties.put("weatherCondition", weatherConditionElem.getAttribute("weather-summary"));
            properties.put("zipCode", zip);
        } catch (SAXException | IOException | ParserConfigurationException ex) {
            throw new RuntimeException("There was a problem with the URL");
        }

        return properties;
    }
}