package com.pranikchainani.ui;

import com.pranikchainani.*;

import java.io.*;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * Created by pranikchainani on 5/21/16.
 */
public class WeatherGeneratorUI {
    public static void main(String[] args) throws IOException {
        List<String> zipCodes = readFile("zipCodes.txt");
        WeatherGenerator weatherGenerator = new WeatherGenerator();

        Properties validAndInvalidZipCodes = weatherGenerator.checkValidZipCode(zipCodes);

        System.out.println("The Invalid zipCodes are: " + validAndInvalidZipCodes.getProperty("invalidZipCode"));

        List<String> validZipCodes = (List<String>) validAndInvalidZipCodes.get("validZipCode");

        List<Properties> combinedDetails = weatherGenerator.combineWeatherAndLocationData(weatherGenerator
                                                            .getLocationDetails(validZipCodes),
                                                            weatherGenerator.getWeatherDetails(validZipCodes));
        display(combinedDetails);
        printWarmestCities(weatherGenerator.getWarmestCity(combinedDetails));
        printColdestCities(weatherGenerator.getColdestCity(combinedDetails));
    }

    public static List<String> readFile(String file) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(file));
        return br.lines().collect(Collectors.toList());
    }

    public static void display(List<Properties> combinedDetails)
    {
        System.out.println("Weather Details:\n");
        System.out.println("City\tState\tZip Code\tMax Temp\tMin Temp\tCondition\n");
        for (Properties properties: combinedDetails)
            System.out.println(properties.getProperty("city")+"\t"+properties.getProperty("state")+"\t"+
                    properties.getProperty("zipCode")+"\t"+properties.getProperty("maxTemp")+"\t"
                    +properties.getProperty("minTemp")+"\t"+properties.getProperty("weatherCondition"));
    }

    private static void printColdestCities(List<Properties> coldestCities) {
        System.out.println("Coldest City/Cities:\n");
        for (Properties city: coldestCities)
            System.out.println(city.getProperty("city")+"\t"+city.getProperty("state")+"\t"+city.getProperty("" + "postalCode")+"\n");
    }

    private static void printWarmestCities(List<Properties> warmestCities) {
        System.out.println("Hottest City/Cities:\n");
        for (Properties city: warmestCities)
            System.out.println(city.getProperty("city")+"\t"+city.getProperty("state")+"\t"+city.getProperty("" +
                    "postalCode")+"\n");
    }
}