package com.pranikchainani;

import java.util.Properties;

/**
 * Created by pranikchainani on 5/8/16.
 */
public interface LocationService {
    Properties getLocationDetails(String zip);
}
