package com.pranikchainani;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

import static java.util.stream.Collectors.toList;

/**
 * Created by pranikchainani on 3/26/16.
 */
public class WeatherGenerator {
    public Properties checkValidZipCode(List<String> zip) {
        Properties resultProps = new Properties();
        ArrayList<String> correctZipList = new ArrayList<String>();
        ArrayList<String> incorrectZipList = new ArrayList<String>();

        zip.stream()
           .forEach(zipCode -> (zipCode.matches("[0-9]+")&& zipCode.length() == 5 ? correctZipList :
                   incorrectZipList).add(zipCode));

        resultProps.put("validZipCode",correctZipList);
        resultProps.put("invalidZipCode",incorrectZipList);

        return resultProps;
    }

    public List<Properties> getWarmestCity(List<Properties> cities) {
        int maxTemp = Integer.parseInt(cities.stream()
                     .max(Comparator.comparingInt(city -> Integer.parseInt(city.getProperty("maxTemp"))))
                     .get()
                     .getProperty("maxTemp"));

        return cities.stream()
                     .filter(city -> Integer.parseInt(city.getProperty("maxTemp")) == maxTemp)
                     .collect(toList());
    }

    public List<Properties> getColdestCity(List<Properties> cities) {
        int minTemp = Integer.parseInt(cities.stream().min(Comparator.comparingInt(city -> Integer.parseInt(city.getProperty("minTemp"))))
                            .get()
                            .getProperty("minTemp"));

        return cities.stream()
                     .filter(city -> Integer.parseInt(city.getProperty("minTemp")) == minTemp)
                     .collect(toList());
    }

    public List<Properties> combineWeatherAndLocationData(List<Properties> locationDetails,
                                                          List<Properties> weatherDetails)
    {
        List<Properties> dataPerZipCode = new ArrayList<>();
        for( Properties location : locationDetails){
            Properties data = new Properties();
            weatherDetails.stream()
                          .filter(weather -> location.getProperty("postalCode").equals(weather.getProperty("zipCode")))
                          .forEach(weather -> {
                                                data.putAll(location);
                                                data.putAll(weather);
                          });
            dataPerZipCode.add(data);
        }
        return dataPerZipCode;
    }

    public List<Properties> getLocationDetails(List<String> zipCodes) {
        List<Properties> locationDetails = new ArrayList<>();

        LocationService locationService = new GoogleLocationService();

        zipCodes.stream()
                .forEach(zipCode -> locationDetails.add(locationService.getLocationDetails(zipCode)));

        return locationDetails;
    }

    public List<Properties> getWeatherDetails(List<String> zipCodes) {
        List<Properties> weatherDetails = new ArrayList<>();

        WeatherService weatherService = new NationalWeatherService();

        zipCodes.stream()
                .forEach(zipCode -> weatherDetails.add(weatherService.getWeatherDetails(zipCode)));

        return weatherDetails;
    }
}