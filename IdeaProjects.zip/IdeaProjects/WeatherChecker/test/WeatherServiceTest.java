import com.pranikchainani.NationalWeatherService;
import com.pranikchainani.WeatherService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

import static junit.framework.TestCase.assertTrue;

/**
 * Created by pranikchainani on 5/15/16.
 */
public class WeatherServiceTest {
    WeatherService weatherService;
    @Before
    public void initialize()
    {
        weatherService = new NationalWeatherService();
    }
    @Test
    public void returnsOnlyNumbersForMaxTemp() throws ParserConfigurationException, SAXException, IOException {
        assertTrue(weatherService.getWeatherDetails("77070").getProperty("maxTemp").matches("[0-9]+"));
    }
    @Test
    public void returnsOnlyNumbersForMinTemp() throws ParserConfigurationException, SAXException, IOException {
       assertTrue(weatherService.getWeatherDetails("77070").getProperty("minTemp").matches("[0-9]+"));
    }
    @Test
    public void checkIfMinTempIsLessThanMaxTemp() throws ParserConfigurationException, SAXException, IOException {
        assertTrue(Integer.parseInt(weatherService.getWeatherDetails("77070").getProperty("minTemp")) <=
                Integer.parseInt(weatherService.getWeatherDetails("77070").getProperty("maxTemp")));
    }
    @Test
    public void correctWeatherDescription() throws ParserConfigurationException, SAXException, IOException {
        junit.framework.Assert.assertTrue(weatherService.getWeatherDetails("77070").containsKey("weatherCondition"));
    }
    @Test
    public void weatherServiceShowsTestForIncompleteness() {
        try {
            weatherService.getWeatherDetails("12412341234");
            Assert.fail("There was a runtime exception caused by an invalid zip code");
        }
        catch(RuntimeException ex)
        {
            assertTrue(true);
        }
    }
}
