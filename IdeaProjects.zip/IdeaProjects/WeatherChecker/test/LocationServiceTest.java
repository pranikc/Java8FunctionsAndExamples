import com.pranikchainani.GoogleLocationService;
import com.pranikchainani.LocationService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * Created by pranikchainani on 5/8/16.
 */
public class LocationServiceTest {
    LocationService locationService;
    @Before
    public void initialize() {
        locationService = new GoogleLocationService();
    }
    @Test
    public void correctState()
    {
        assertEquals("TX", locationService.getLocationDetails("77070").getProperty("state"));
    }
    @Test
    public void correctCity()
    {
        assertEquals("Houston", locationService.getLocationDetails("77070").getProperty("city"));
    }
    @Test
    public void locationServiceThrowsErrorForIncompleteness(){
        try{
            locationService.getLocationDetails("12312412871525");
            Assert.fail("A Runtime exception was expected cause input zip was invalid.");
        }catch(RuntimeException ex)
        {
            assertTrue(true);
        }
    }
}
