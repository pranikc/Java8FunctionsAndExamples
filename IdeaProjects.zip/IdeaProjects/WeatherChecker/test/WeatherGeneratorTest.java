import com.pranikchainani.WeatherGenerator;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by pranikchainani on 3/26/16.
 */
public class WeatherGeneratorTest {
    WeatherGenerator weatherGeneratorTest;
    //ArrayList of Strings
    @Test
    public void Canary() { assertTrue(true); }
    @Before
    public void initialize(){
        weatherGeneratorTest = new WeatherGenerator();
    }
    @Test
    public void checkZipCodeContainsOnlyNumbers() {
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("12345");
        zipList.add("23415");
        zipList.add("23541");

        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("validZipCode"));
    }
    @Test
    public void checkZipCodeContainsOnlyAlphabets() {
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("jsjda");
        zipList.add("ajusk");
        zipList.add("1as48");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("invalidZipCode"));
    }
    @Test
    public void checkZipCodeContainsOnlySpecialCharacters(){
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("@##$^");
        zipList.add("*@#($");
        zipList.add("$&#@(");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("invalidZipCode"));
    }
    @Test
    public void checkZipCodeContainsOnlyEmptyValue()
    {
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("");
        zipList.add("");
        zipList.add("");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("invalidZipCode"));
    }
    @Test
    public void checkZipCodeContainsOnly5Numbers()
    {
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("23415");
        zipList.add("19224");
        zipList.add("19132");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("validZipCode"));
    }
    @Test
    public void checkZipCodeContainsNumbersLessThan5() {
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("2374");
        zipList.add("1234");
        zipList.add("4331");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("invalidZipCode"));
    }
    @Test
    public void checkZipCodeContainsNumbersGreaterThan5(){
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("123453");
        zipList.add("173832");
        zipList.add("181982");
        assertEquals(zipList,weatherGeneratorTest.checkValidZipCode(zipList).get("invalidZipCode"));
    }
    @Test
    public void checkEmptyList(){
        ArrayList<String> zipList = new ArrayList<String>();
        zipList.add("");
        zipList.add("");
        zipList.add("");
        for (String zip: zipList)
        {
            if (zip.length() == 0)
            {
                assertTrue(true);
            }
        }
    }
    @Test
    public void getWarmestCityReturnsHighestTemp()
    {
        Properties houston = new Properties();
        Properties newYork = new Properties();
        Properties florida = new Properties();
        Properties sanFrancisco = new Properties();
        Properties london = new Properties();

        houston.setProperty("maxTemp", "100");
        newYork.setProperty("maxTemp", "60");
        florida.setProperty("maxTemp", "105");
        sanFrancisco.setProperty("maxTemp", "90");
        london.setProperty("maxTemp", "55");

        List<Properties> cities = new ArrayList<>(Arrays.asList(florida,houston,newYork,sanFrancisco,london));

        List<Properties> expectedResult = new ArrayList<>(Arrays.asList(florida));
        assertEquals(expectedResult, weatherGeneratorTest.getWarmestCity(cities));
    }

    @Test
    public void getWarmestCityReturnHighestTempFor2Cities(){
        Properties houston = new Properties();
        Properties newYork = new Properties();
        Properties florida = new Properties();
        Properties sanFrancisco = new Properties();
        Properties london = new Properties();

        houston.setProperty("maxTemp", "105");
        newYork.setProperty("maxTemp", "60");
        florida.setProperty("maxTemp", "105");
        sanFrancisco.setProperty("maxTemp", "90");
        london.setProperty("maxTemp", "55");

        List<Properties> cities = new ArrayList<>(Arrays.asList(florida,houston,newYork,sanFrancisco,london));

        List<Properties> expectedResult = new ArrayList<>(Arrays.asList(florida,houston));
        assertEquals(expectedResult, weatherGeneratorTest.getWarmestCity(cities));
    }
    @Test
    public void getColdestCityReturnsLowestTemp()
    {
        Properties houston = new Properties();
        Properties newYork = new Properties();
        Properties florida = new Properties();
        Properties sanFrancisco = new Properties();
        Properties london = new Properties();

        houston.setProperty("minTemp", "75");
        newYork.setProperty("minTemp", "50");
        florida.setProperty("minTemp", "85");
        sanFrancisco.setProperty("minTemp", "70");
        london.setProperty("minTemp", "45");

        List<Properties> cities = new ArrayList<>(Arrays.asList(florida,houston,newYork,sanFrancisco,london));

        List<Properties> expectedResult = new ArrayList<>(Arrays.asList(london));
        assertEquals(expectedResult, weatherGeneratorTest.getColdestCity((cities)));
    }
    @Test
    public void getColdestCityReturnColdestTempFor2Cities(){
        Properties houston = new Properties();
        Properties newYork = new Properties();
        Properties florida = new Properties();
        Properties sanFrancisco = new Properties();
        Properties london = new Properties();

        houston.setProperty("minTemp", "75");
        newYork.setProperty("minTemp", "45");
        florida.setProperty("minTemp", "85");
        sanFrancisco.setProperty("minTemp", "70");
        london.setProperty("minTemp", "45");

        List<Properties> cities = new ArrayList<>(Arrays.asList(florida,houston,newYork,sanFrancisco,london));

        List<Properties> expectedResult = new ArrayList<>(Arrays.asList(newYork, london));
        assertEquals(expectedResult, weatherGeneratorTest.getColdestCity(cities));
    }
    @Test
    public void combineLocationAndWeatherTest()
    {
        Properties houstonWeatherProps = new Properties();
        Properties houstonLocationProps = new Properties();

        houstonWeatherProps.setProperty("weatherCondition", "Chance Thunderstorms");
        houstonWeatherProps.setProperty("zipCode","77070");
        houstonWeatherProps.setProperty("maxTemp","73");
        houstonWeatherProps.setProperty("minTemp","93");

        houstonLocationProps.setProperty("postalCode", "77070");
        houstonLocationProps.setProperty("city", "Houston");
        houstonLocationProps.setProperty("state", "TX");

        List<Properties> expectedOutput = new ArrayList<>();
        Properties expectedProps = new Properties();
        expectedProps.putAll(houstonWeatherProps);
        expectedProps.putAll(houstonLocationProps);
        expectedOutput.add(expectedProps);

        assertEquals(expectedOutput, weatherGeneratorTest.combineWeatherAndLocationData(Arrays.asList(houstonLocationProps), Arrays.asList(houstonWeatherProps)));
    }
    @Test
    public void getLocationDetailsFromListOfZipCodes() throws IOException, SAXException, ParserConfigurationException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("77070");
        zipCodes.add("77063");

        assertEquals(zipCodes.size(), weatherGeneratorTest.getWeatherDetails(zipCodes).size());
    }
    @Test
    public void getWeatherDetailsFromListOfZipCodes() throws IOException, SAXException, ParserConfigurationException {
        List<String> zipCodes = new ArrayList<>();
        zipCodes.add("77070");
        zipCodes.add("77063");

        assertEquals(zipCodes.size(), weatherGeneratorTest.getLocationDetails(zipCodes).size());
    }
}