import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URL;

/**
 * Created by pranikchainani on 5/4/16.
 */
public class XMLParserTest {
    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {
        InputStream is = new URL("http://graphical.weather.gov/xml/sample_products/browser_interface/ndfdBrowserClientByDay.php?zipCodeList=77070&format=24+hourly&numDays=1").openStream();

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(is);

        //optional, but recommended
        //read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
        doc.getDocumentElement().normalize();

        Element maxTempElem = (Element) doc.getElementsByTagName("temperature").item(0);
        Element minTempElem = (Element) doc.getElementsByTagName("temperature").item(1);
        Element weatherConditionElem = (Element) doc.getElementsByTagName("weather-conditions").item(0);

        int maxTemp = Integer.parseInt((maxTempElem.getElementsByTagName("value").item(0).getTextContent()));
        int minTemp = Integer.parseInt((minTempElem.getElementsByTagName("value").item(0).getTextContent()));
        String weatherCondition = weatherConditionElem.getAttribute("weather-summary");

        System.out.println(maxTemp);
        System.out.println(minTemp);
        System.out.println(weatherCondition);
    }
}
