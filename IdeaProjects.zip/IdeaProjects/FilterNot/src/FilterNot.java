import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import static java.util.stream.Collectors.partitioningBy;

/**
 * Created by pranikchainani on 7/1/16.
 */
public class FilterNot {
    public static boolean isMultipleOf3(int number){
        return number % 3 == 0;
    }

    // Take a predicate as input and produce a predicate negate as output

    public static <T> Predicate<T> not(Predicate<T> preredicate){
        return preredicate.negate();
    }

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);

//        numbers.stream()
//                .filter(FilterNot::isMultipleOf3)
//                .forEach((System.out::println));

//        Predicate<Integer> predicate = FilterNot::isMultipleOf3;
//
//        numbers.stream()
//                .filter(predicate.negate())
//                .forEach(System.out::println);

//        numbers.stream()
//                .filter(not(FilterNot::isMultipleOf3))
//                .forEach(System.out::println);

        System.out.println(numbers.stream()
                                .collect(partitioningBy(FilterNot::isMultipleOf3)));
    }
}