import java.util.stream.IntStream;

/**
 * Created by pranikchainani on 7/1/16.
 */
public class PrimeMethods {
    public static boolean isPrimeImperative(int number)
    {
        boolean isPrimeNumber = true;

        for (int i = 2; i <= Math.sqrt(number); i++)
        {
            if (number % i == 0)
            {
                isPrimeNumber = false;
                break;
            }
        }
        return number!=1 && isPrimeNumber;
    }

    public static boolean isPrimeFunctional(int number)
    {
        return number !=1 && IntStream.rangeClosed(2, (int) Math.sqrt(number))
                                        .noneMatch(i -> number%i==0);
    }

    public static void main(String[] args) {
        IntStream.rangeClosed(1, 13)
                 .forEach(number -> System.out.println(number + "->" + isPrimeFunctional(number)));
    }
}