import java.util.HashMap;
import java.util.Map;

/**
 * Created by pranikchainani on 6/10/16.
 */
public class FibonacciMemoization extends FibonacciRecursive {
    static Map<Integer, Integer> cache = new HashMap<>();

    static {
        cache.put(0,1);
        cache.put(-1,0);
        cache.put(1,1);
    }

    public int fibonacciValue(int position){
        return cache.computeIfAbsent(position, n -> super.fibonacciValue(position));
    }
}