/**
 * Created by pranikchainani on 6/5/16.
 */
public class FibonacciRecursive implements Fibonacci{
    public int fibonacciValue(int position)
    {
        if (position < 0)
        {
            return 0;
        }
        else if (position < 2)
        {
            return 1;
        }

        return fibonacciValue(position - 2) + fibonacciValue(position - 1);
    }
}