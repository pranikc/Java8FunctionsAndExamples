/**
 * Created by pranikchainani on 6/5/16.
 */
public interface Fibonacci {
    int fibonacciValue(int position);
}
