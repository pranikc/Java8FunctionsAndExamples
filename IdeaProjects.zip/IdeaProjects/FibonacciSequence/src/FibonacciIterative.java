import java.util.stream.IntStream;

/**
 * Created by pranikchainani on 6/3/16.
 */
public class FibonacciIterative implements Fibonacci{

    public int fibonacciValue(int position) {
        if (position < 1 && position >= 0) {
            return 1;
        }
        else if (position < 0)
        {
            return 0;
        }

        // Try the function below with parallel

//        final int[] newValue = {1};
//        final int[] currentValue = {0};
//
//        IntStream.rangeClosed(1, position).forEach(nbr -> {
//            newValue[0] = currentValue[0] + newValue[0];
//            currentValue[0] = newValue[0] - currentValue[0];
//        });
//
//        return newValue[0];

       return IntStream.rangeClosed(1, position+1)
                .mapToObj(i -> new int[] {})
                .reduce(new int[] {1, 0}, this::computeNext)[1];
    }

    private int[] computeNext(int[] pair, int[] ignore) {
        return new int[] { pair[1], pair[0] + pair[1] };
    }

}
