import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by pranikchainani on 6/11/16.
 */
public class FibonacciPerformanceTests {
    Fibonacci fibonacciRecursive  = new FibonacciRecursive();
    Fibonacci fibonacciMemoization = new FibonacciMemoization();
    Fibonacci fibonacciIterative = new FibonacciIterative();

    @Test
    public void checkPerformance(){
        int position = 43;

        System.out.println("Recursive   : "+ timeCalculation(fibonacciRecursive, position));
        System.out.println("Memoization : "+ timeCalculation(fibonacciMemoization, position));
        System.out.println("Iterative   : "+ timeCalculation(fibonacciIterative, position));

        assertTrue(timeCalculation(fibonacciRecursive, position) > 10 * timeCalculation(fibonacciMemoization, position));
    }
    public long timeCalculation(Fibonacci fibonacciAlgorithm, int position){
        long startTime = System.nanoTime();
        fibonacciAlgorithm.fibonacciValue(position);
        long endTime = System.nanoTime();

        return endTime - startTime;
    }
}
