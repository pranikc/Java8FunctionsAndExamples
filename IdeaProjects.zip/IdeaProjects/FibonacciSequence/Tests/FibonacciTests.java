import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * Created by pranikchainani on 6/10/16.
 */

@RunWith(Parameterized.class)
public abstract class FibonacciTests {
    Fibonacci fibonacci;

    int expectedValue, termNumber;

    public FibonacciTests(int value1, int value2){
        termNumber = value1;
        expectedValue = value2;
    }
    public abstract Fibonacci createFibonacci();

    @Before
    public void initialize() {
        fibonacci = createFibonacci();
    }
    @Test
    public void canary()
    {
        assertTrue(true);
    }

    @Parameterized.Parameters
    public static Collection inputValues(){
        return Arrays.asList(new Object[][]{
                {0,1},
                {1,1},
                {-1,0},
                {42,433494437},
                {6, 13}
        });
    }

    @Test
    public void fibonacciChecksForGivenNumber() {
        assertEquals(expectedValue, fibonacci.fibonacciValue(termNumber));
    }
}