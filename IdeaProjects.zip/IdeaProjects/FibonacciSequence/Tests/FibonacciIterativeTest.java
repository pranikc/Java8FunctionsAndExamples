/**
 * Created by pranikchainani on 6/3/16.
 */

public class FibonacciIterativeTest extends FibonacciTests{
    public FibonacciIterativeTest(int value1, int value2){
        super(value1,value2);
    }

    public Fibonacci createFibonacci()
    {
        return new FibonacciIterative();
    }
}