/**
 * Created by pranikchainani on 6/5/16.
 */

public class FibonacciRecursiveTest extends FibonacciTests{
    public FibonacciRecursiveTest(int value1, int value2){
        super(value1,value2);
    }

    @Override
    public Fibonacci createFibonacci()
    {
        return new FibonacciRecursive();
    }
}
