/**
 * Created by pranikchainani on 6/10/16.
 */
public class FibonacciMemoizationTest extends FibonacciTests {

    public FibonacciMemoizationTest(int value1, int value2){
        super(value1,value2);
    }

    @Override
    public Fibonacci createFibonacci()
    {
        return new FibonacciMemoization();
    }

}