import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Created by pranikchainani on 7/1/16.
 */
public class ForEachOrdered {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1,2,3,10,2,7);
        Set<Integer> numberSet = new HashSet<>(Arrays.asList(1,2,3,10,2,7));

        forEach(numbers.parallelStream());
        System.out.println("--------");
        forEachOrdered(numbers.parallelStream());
    }

    private static void forEachOrdered(Stream<Integer> stream) {
        stream.forEachOrdered(System.out::println);
    }

    private static void forEach(Stream<Integer> stream) {
        stream.forEach(System.out::println);
    }
}
